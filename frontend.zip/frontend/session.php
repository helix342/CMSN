<?php
session_start();

$s = 'principal';
// $s = '1152061'; //faculty
//$s = '1152062'; //infra
//$s = '1152063'; //hod
//$s = '1141014'; //eo
//$s = '1112001'; //manager


$query = "SELECT sid,sname, dept,ayear FROM student WHERE sid='$s'";
$query_run = mysqli_query($db, $query);
if (mysqli_num_rows($query_run) > 0) {
	$srow = mysqli_fetch_assoc($query_run);
	$sdept = $srow['dept'];
	$sname = $srow['sname'];
	$sayear = $srow['ayear'];
	$sid = $srow['sid'];
}

$query2 = "SELECT id,name,dept,role FROM faculty WHERE id='$s'";
$query_run2 = mysqli_query($db, $query2);
if (mysqli_num_rows($query_run2) > 0) {
	$frow = mysqli_fetch_assoc($query_run2);
	$fdept = $frow['dept'];
	$fname = $frow['name'];
	$frole = $frow['role'];
	$fac_id = $frow['id'];
}


$query3 = "SELECT gender FROM sbasic WHERE sid='$s'";
$query_run3 = mysqli_query($db, $query3);
if (mysqli_num_rows($query_run3) > 0) {
	$srow2 = mysqli_fetch_assoc($query_run3);
	$sgender = $srow2['gender'];
}
